(function (window) {
  window["env"] = window["env"] || {};

  // Environment variables
  // window["env"]["apiUrl"] = "${API_URL}";
    window["env"]["apiUrl"] = "http://localhost:8080/api/v1.0";

})(this);
