export const environment = {
  production: true,
  serverUrl: window["env"]["apiUrl"] || "default",
};
