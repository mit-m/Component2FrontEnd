
module.exports = {
  important: true,
  purge: {
    enabled: false,
    content: ["./src/**/*.html", "./src/**/*.scss"],
  },
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
};
